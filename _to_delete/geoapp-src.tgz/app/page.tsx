'use client';

import Navbar from '@/features/home/components/Navbar';
import Hero from '@/features/home/components/hero';
import About from '@/features/home/components/about';
import Features from '@/features/home/components/features';
import DataSources from '@/features/home/components/data-sources';
import Contact from '@/features/home/components/contact';
import Footer from '@/features/home/components/Footer';
import { useScrollY } from '@/features/home/useScrollY';

export default function Home() {
  const scrollY = useScrollY();
  const navScrolled = scrollY > 30;

  return (
    <div className="relative bg-white min-h-screen overflow-hidden">
      
      {/* ── UNIFIED GLOBAL BACKGROUND ── */}
      <div className="absolute top-[-112px] right-[-112px] w-[760px] h-[760px] rounded-full pointer-events-none z-0"
        style={{ background: 'radial-gradient(circle, #e0faf4 0%, transparent 62%)', transform: `translateY(${scrollY * 0.11}px)` }} />
      <div className="absolute top-[40vh] -left-16 w-[360px] h-[360px] rounded-full pointer-events-none z-0"
        style={{ background: 'radial-gradient(circle, #fff1f0 0%, transparent 65%)', transform: `translateY(${scrollY * -0.05}px)` }} />
      <div className="absolute top-[80vh] -left-24 w-[560px] h-[560px] rounded-full pointer-events-none z-0"
        style={{ background: 'radial-gradient(circle, #fff7ed 0%, transparent 62%)', transform: `translateY(${scrollY * -0.07}px)` }} />

      <svg className="fixed inset-0 w-full h-full opacity-[0.22] pointer-events-none z-0">
        <defs><pattern id="bg-dots" width="28" height="28" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="0.9" fill="#94a3b8" /></pattern></defs>
        <rect width="100%" height="100%" fill="url(#bg-dots)" />
      </svg>
      <svg className="fixed top-0 right-[40%] h-full w-0.5 opacity-[0.06] pointer-events-none z-0">
        <line x1="1" y1="0" x2="1" y2="100%" stroke="#0f172a" strokeWidth="1" strokeDasharray="6 6" />
      </svg>

      {/* ── CONTENT ── */}
      <Navbar isScrolled={navScrolled} />
      
      <div className="relative z-10">
        <Hero />
        <About />
        <Features />
        <DataSources />
        <Contact />
        <Footer />
      </div>
    </div>
  );
}