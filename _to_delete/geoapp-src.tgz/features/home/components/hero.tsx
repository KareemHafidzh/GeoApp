'use client';

import { memo } from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';
import { RISK_LEVELS, DATA_UPDATED } from '@/features/map/constants';
import { KECAMATAN, TOTALS, FLOODS_BY_YEAR, LANDSLIDES_BY_YEAR } from '@/features/home/stats';

// MapLibre needs the browser.
const RiskGlobe = dynamic(() => import('./RiskGlobe'), {
  ssr: false,
  loading: () => <div className="w-full h-full rounded-full bg-sky-100/60 animate-pulse" />,
});

const mono = { fontFamily: 'DM Mono, monospace' };
const syne = { fontFamily: 'Syne, sans-serif' };
const card = 'bg-white/80 backdrop-blur-md border border-white rounded-3xl shadow-[0_8px_30px_rgba(15,23,42,0.06)]';
const RISK_HEX = Object.fromEntries(RISK_LEVELS.map((r) => [r.label, r.color]));
const riskCount = (label: string) => KECAMATAN.filter((k) => k.risk === label).length;
const fmt = (n: number) => n.toLocaleString('id-ID');

function Icon({ d, bg }: { d: string; bg: string }) {
  return (
    <div className="w-11 h-11 shrink-0 rounded-2xl flex items-center justify-center" style={{ background: bg }}>
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-slate-800"><path d={d} /></svg>
    </div>
  );
}

function MiniBars({ values, color }: { values: { year: string; value: number }[]; color: string }) {
  const max = Math.max(...values.map((v) => v.value), 1);
  return (
    <div className="flex items-end gap-2 h-14 mt-3">
      {values.map((v) => (
        <div key={v.year} className="flex-1 flex flex-col items-center gap-1">
          <div className="w-full rounded-md" style={{ height: `${Math.max(6, (v.value / max) * 40)}px`, background: color }} />
          <span className="text-[9px] text-slate-400" style={mono}>{v.year}</span>
        </div>
      ))}
    </div>
  );
}

// memo: page.tsx re-renders on every scroll (navbar/parallax); the hero has nothing that depends on it.
export default memo(function Hero() {
  const topAffected = KECAMATAN.slice(0, 6);
  const maxAffected = topAffected[0].affected;
  const avgDensity = Math.round(TOTALS.population / TOTALS.areaKm2);

  return (
    <section className="relative px-5 sm:px-8 lg:px-12 pt-28 pb-16">
      <div className="max-w-[1320px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-5">

        {/* ── LEFT: headline + key stats ── */}
        <div className="lg:col-span-3 flex flex-col gap-4 order-1">
          <div className="anim-fade-up">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-600 uppercase mb-4" style={{ ...mono, fontSize: 10, letterSpacing: '0.12em' }}>
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-blink" /> Kota Bekasi · Data 2025
            </div>
            <h1 className="font-extrabold text-slate-900 leading-[1.05] tracking-[-0.03em]" style={{ ...syne, fontSize: 'clamp(2.2rem, 3.4vw, 3.2rem)' }}>
              Disaster <span className="text-[#0aab8a]">Risk</span> Atlas
            </h1>
            <p className="text-slate-500 mt-2 text-sm" style={syne}>K-Means clustering of 12 kecamatan. Real data, safer city.</p>
          </div>

          <div className="anim-fade-up" style={{ animationDelay: '0.1s' }}>
            <div className="text-slate-700 text-sm font-semibold" style={syne}>Kecamatan berisiko tinggi</div>
            <div className="font-extrabold text-slate-900 leading-none mt-1" style={{ ...syne, fontSize: 64 }}>
              {riskCount('Risiko Tinggi')}<span className="text-slate-300 text-4xl"> / 12</span>
            </div>
            <span className="inline-block mt-3 px-2.5 py-1 rounded-lg bg-red-50 text-red-600 text-xs font-bold" style={mono}>
              {fmt(KECAMATAN.filter((k) => k.risk === 'Risiko Tinggi').reduce((a, k) => a + k.affected, 0))} kelurahan terdampak di zona ini (2021, 2024, 2025)
            </span>
          </div>

          {[
            { label: 'Total Penduduk', value: `${(TOTALS.population / 1e6).toFixed(2)} jt`, sub: `${TOTALS.areaKm2} km² wilayah`, bg: '#e0f2fe', d: 'M8 11a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm8 0a2.5 2.5 0 1 0 0-5M2 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16 14c2.8 0 5 2.2 5 5' },
            { label: 'Kelurahan Terdampak Bencana', value: fmt(TOTALS.affected), sub: 'banjir + longsor · 2021 + 2024 + 2025', bg: '#fee2e2', d: 'M12 3 2 20h20zM12 10v4M12 17h.01' },
            { label: 'Fasilitas Kesehatan', value: fmt(TOTALS.healthFacilities), sub: 'RS + puskesmas · BPS', bg: '#dcfce7', d: 'M12 5v14M5 12h14' },
          ].map((s, i) => (
            <div key={s.label} className={`${card} anim-fade-up p-4 flex items-center gap-4`} style={{ animationDelay: `${0.15 + i * 0.07}s` }}>
              <Icon d={s.d} bg={s.bg} />
              <div>
                <div className="text-slate-500 text-xs" style={syne}>{s.label}</div>
                <div className="font-extrabold text-slate-900 text-2xl" style={syne}>{s.value}</div>
                <div className="text-slate-400 text-[10px]" style={mono}>{s.sub}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ── CENTER: 3D globe → Bekasi ── */}
        <div className="lg:col-span-6 order-2 relative h-[420px] sm:h-[540px] lg:h-auto lg:min-h-[640px] anim-fade-in">
          <div className="absolute inset-0 rounded-[36px] overflow-hidden bg-gradient-to-b from-sky-50 to-white">
            <RiskGlobe />
          </div>
          <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-white/90 backdrop-blur-sm border border-slate-200 rounded-full px-3 py-1.5 shadow-sm pointer-events-none"
            style={{ ...mono, fontSize: 10, color: '#0aab8a' }}>
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-blink" /> 3D · tinggi = kelurahan terdampak
          </div>
        </div>

        {/* ── RIGHT: affected + risk distribution ── */}
        <div className="lg:col-span-3 order-3 flex flex-col gap-4">
          <div className={`${card} p-5 anim-fade-up`} style={{ animationDelay: '0.2s' }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900 text-sm" style={syne}>Kelurahan Terdampak per Kecamatan</h3>
              <span className="text-[10px] text-slate-400 border border-slate-200 rounded-lg px-2 py-0.5" style={mono}>Top 6</span>
            </div>
            <div className="flex flex-col gap-3">
              {topAffected.map((k) => (
                <div key={k.name} className="grid grid-cols-[96px_1fr_24px] items-center gap-2">
                  <span className="text-xs text-slate-600 truncate" style={syne}>{k.name}</span>
                  <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(k.affected / maxAffected) * 100}%`, background: RISK_HEX[k.risk] }} />
                  </div>
                  <span className="text-xs font-bold text-slate-800 text-right" style={mono}>{k.affected}</span>
                </div>
              ))}
            </div>
          </div>

          <div className={`${card} p-5 anim-fade-up`} style={{ animationDelay: '0.28s' }}>
            <h3 className="font-bold text-slate-900 text-sm mb-4" style={syne}>Distribusi Risiko (K=3)</h3>
            <div className="flex h-3 rounded-full overflow-hidden mb-4">
              {RISK_LEVELS.map((r) => <div key={r.label} style={{ flex: riskCount(r.label), background: r.color }} />)}
            </div>
            {RISK_LEVELS.map((r) => (
              <div key={r.label} className="flex items-center justify-between py-1.5">
                <span className="flex items-center gap-2 text-xs text-slate-600" style={syne}>
                  <span className="w-2.5 h-2.5 rounded-full" style={{ background: r.color }} /> {r.label}
                </span>
                <span className="text-xs font-bold text-slate-800" style={mono}>{riskCount(r.label)} kec.</span>
              </div>
            ))}
            <p className="text-[10px] text-slate-400 mt-3 leading-relaxed" style={mono}>
              Kepadatan tinggi ≠ risiko tinggi: Bekasi Barat terpadat namun berisiko rendah.
            </p>
          </div>
        </div>

        {/* ── BOTTOM: KPI cards + CTA ── */}
        <div className="lg:col-span-12 order-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className={`${card} p-5`}>
            <div className="text-xs text-slate-500" style={syne}>Kelurahan Terdampak Banjir</div>
            <div className="font-extrabold text-3xl text-slate-900" style={syne}>{TOTALS.floods}</div>
            <MiniBars values={FLOODS_BY_YEAR} color="#60a5fa" />
          </div>
          <div className={`${card} p-5`}>
            <div className="text-xs text-slate-500" style={syne}>Kelurahan Terdampak Longsor</div>
            <div className="font-extrabold text-3xl text-slate-900" style={syne}>{TOTALS.landslides}</div>
            <MiniBars values={LANDSLIDES_BY_YEAR} color="#f59e0b" />
          </div>
          <div className={`${card} p-5`}>
            <div className="text-xs text-slate-500" style={syne}>Kepadatan rata-rata</div>
            <div className="font-extrabold text-3xl text-slate-900" style={syne}>{fmt(avgDensity)}</div>
            <div className="text-[10px] text-slate-400 mt-1" style={mono}>jiwa / km²</div>
            <div className="flex items-end gap-1 h-12 mt-2">
              {KECAMATAN.map((k) => <div key={k.name} title={k.name} className="flex-1 rounded-sm bg-violet-400/80" style={{ height: `${(k.density / 19135) * 100}%` }} />)}
            </div>
          </div>
          <div className={`${card} p-5`}>
            <div className="text-xs text-slate-500" style={syne}>Sekolah (SMP–SMA/K)</div>
            <div className="font-extrabold text-3xl text-slate-900" style={syne}>{fmt(TOTALS.schools)}</div>
            <div className="text-[10px] text-slate-400 mt-1" style={mono}>SMP + SMA/K · BPS</div>
          </div>
          <div className="rounded-3xl p-5 bg-gradient-to-br from-slate-900 to-emerald-900 text-white flex flex-col justify-between sm:col-span-2 lg:col-span-1">
            <div>
              <div className="font-bold text-lg leading-tight" style={syne}>Jelajahi peta risiko interaktif</div>
              <p className="text-white/60 text-xs mt-2" style={mono}>Ukur area, cari faskes terdekat, filter kelas risiko.</p>
            </div>
            <Link href="/map" className="mt-4 inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-[#0aab8a] hover:bg-emerald-500 font-bold text-sm transition-colors" style={syne}>
              Open Spatial Map →
            </Link>
          </div>
        </div>

        <p className="lg:col-span-12 order-5 text-[10px] text-slate-400 text-center" style={mono}>Data diperbarui {DATA_UPDATED}</p>
      </div>
    </section>
  );
});
